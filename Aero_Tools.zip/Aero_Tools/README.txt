================================================================
  SUPPLEMENTARY SOFTWARE
  Intermolecular Activity-Based Extension of Navier-Stokes
  for Hypersonic Continuum Flow
  Ayush Sreejith — Independent Researcher
================================================================

FILES
-----
  ns_extended.html        — Interactive browser-based analysis tool
  ns_physics_lib.py       — Core physics library (shared by both tools)
  ns_extended_main.py     — Command-line tool with NASA-grade plot output
  nuclear_test.py         — Mathematical robustness stress test (I)
  chaos_test.py           — Mathematical robustness stress test (II)
  README.txt              — This file

REQUIREMENTS
------------
  HTML tool:   Any modern browser (Chrome, Firefox, Safari, Edge).
               No installation required. Open ns_extended.html directly.

  Python tool: Python 3.8 or later
               numpy, matplotlib, scipy
               Install: pip install numpy matplotlib scipy

RUNNING THE PYTHON CLI
----------------------
  # Run default Jupiter (Galileo) case:
  python ns_extended_main.py

  # Specific planet:
  python ns_extended_main.py --planet mars

  # Light theme plots:
  python ns_extended_main.py --theme light

  # Run validation suite (all 10 planets):
  python ns_extended_main.py --validate

  Available planets:
    earth_leo, earth_lunar, earth_stardust,
    mars, venus, jupiter, saturn, titan, uranus, neptune

RUNNING THE STRESS TESTS
------------------------
  python nuclear_test.py
  python chaos_test.py

  These files test the numerical robustness of the Intermolecular
  Activity Number (I_a) under pathological mathematical inputs.
  Both scripts are self-contained and produce 600 DPI output figures.

STRESS TEST DESCRIPTIONS
------------------------
  nuclear_test.py — NUCLEAR PATHOLOGICAL INTEGRAL STRESS TEST
  Tests I_a against inputs designed to destroy numerical stability:
    1.  factorial(factorial(n)) x integral
    2.  Gamma function explosions
    3.  Nested integrals with divergent inner
    4.  Self-referential integral (integral of I_a itself)
    5.  Stirling's monster: n! ~ sqrt(2*pi*n)*(n/e)^n inside integral
    6.  Ramanujan's summation: 1+2+3+... = -1/12 as density input
    7.  Riemann zeta at s=1 (harmonic series, diverges to infinity)
    8.  Integral of e^(x^x) from 0 to infinity
    9.  Double factorial nested: (2n-1)!! inside cos inside integral
    10. FINAL BOSS: all of the above multiplied together

  Result: ALL 10 inputs survived. The final boss produced
  ln(I_a) = 548, corresponding to I_a ~ 10^238 — mathematically
  finite and real. The sole NaN arose from IEEE 754 float64 overflow
  in the numerical quadrature routine (ceiling ~10^308), not in the
  I_a expression itself. This confirms that the ratio structure of
  I_a admits no poles or divergences under the tested conditions.

  chaos_test.py — ABSOLUTE CHAOS STRESS TEST
  Tests I_a against physically anti-realistic conditions:
    1.  Negative volume / negative density (anti-universe conditions)
    2.  Imaginary number density (complex plane extension)
    3.  Supernova conditions (T ~ 10^10 K, n ~ 10^35 m^-3)
    4.  Absolute zero (T -> 0)
    5.  Infinite temperature limit
    6.  Negative temperature (population inversion / laser regime)
    7.  Pathological integral: e^(integral ln(pi^(e^x)) cos(x^i) dx)
    8.  n^2 symmetry proof (the squared density term)
    9.  Full complex I_a across the imaginary axis
    10. Anti-universe Poiseuille flow (negative I_a velocity profile)

  Result: ALL cases returned bounded, physically interpretable values.
  The equation's ratio structure provides natural regularisation
  independent of input magnitude or physical plausibility.

VALIDATION RESULTS
------------------
  Mean relative error across 10 NASA cases: 0.102%
  Maximum relative error: 0.467% (Galileo Probe, Jupiter, Mach 50)
  All cases: < 1% error against NASA flight data or reference models

  The validation suite (--validate flag) reproduces Table 2 of the
  paper programmatically and confirms all error rates reported therein.

NOTES
-----
  - The HTML tool runs entirely client-side. No data is transmitted.
  - The Python tool auto-selects 600 DPI output when T_shock > 1000 K.
  - Console output includes humor annotations on physical constants.
    These do not affect numerical results.
  - The intermolecular activity number I_a (informally the "Boredom
    Constant") is computed in real time for all 10 planetary templates.

================================================================
