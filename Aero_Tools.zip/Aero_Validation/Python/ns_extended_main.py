"""
═══════════════════════════════════════════════════════════════════════════════
  EXTENDED NAVIER-STOKES — HYPERSONIC CONTINUUM FLOW ANALYSIS
  Interactive CLI + Matplotlib generation,
═══════════════════════════════════════════════════════════════════════════════

  Usage:
    python ns_extended_main.py                    # run default Galileo case
    python ns_extended_main.py --planet mars      # specific planet
    python ns_extended_main.py --theme light      # light mode plots
    python ns_extended_main.py --validate         # run validation suite
    python ns_extended_main.py --dpi 600          # high DPI (auto above 1000K)

  Outputs individual 600 DPI PNGs when any T > 1000 K, collection overview
  otherwise. All plots are production-ready for AIAA-style publications.

───────────────────────────────────────────────────────────────────────────────
"""
import argparse
import os
import sys
import time
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ns_physics_lib import (
    # Physics
    SPECIES, PLANETS, build_mixture, planet_mixture,
    a_species, a_ij, a_mixture, da_mix_dT,
    mu_species, mu_mixture,
    vib_einstein, f_species, f_rad_planck,
    diss_fraction, effective_mixture_after_diss, diss_energy_fraction,
    f_mix, P_IM_bulk, P_IM_r, Ia_number, gradPIM_components,
    select_model, stagnation_heat_flux, validate,
    # Constants
    kB, NA, h_pl, c_ls, sigma_SB, R_u
)

# ══════════════════════════════════════════════════════════════════════════════
# NASA OPENVSP-STYLE CONSOLE with humor
# ══════════════════════════════════════════════════════════════════════════════
class Console:
    """Terminal-style logger with personality. Mimics NASA mission-control readout."""

    # Humor tags for constants
    QUIPS = {
        'la':    '"get back here boy"',
        'alpha': '"I have been erased from the plane of existence"',
        'beta':  '"also erased, no longer exists"',
        'fT':    '"that is really HOT GYADDAMN"',
        'Ia':    '"the number that started it all"',
        'rho':   '"dense vibes only"',
        'P_IM':  '"van der Waals said what?"',
        'sigma': '"radiating harder than the Sun"',
        'diss':  '"breakup simulator 9000"',
        'NA':    '"avogadro\'s revenge"',
    }

    COLORS = {
        'info':   '\033[96m',     # cyan
        'calc':   '\033[92m',     # green
        'warn':   '\033[93m',     # yellow
        'err':    '\033[91m',     # red
        'ok':     '\033[92m',     # green
        'header': '\033[95m',     # magenta
        'dim':    '\033[90m',     # grey
        'reset':  '\033[0m',
        'bold':   '\033[1m',
    }

    def __init__(self, enabled=True, timestamps=True):
        self.enabled = enabled
        self.timestamps = timestamps
        self.t0 = time.time()
        self.buffer = []

    def _ts(self):
        if not self.timestamps: return ''
        elapsed = time.time() - self.t0
        return f'[T+{elapsed:06.2f}s] '

    def _write(self, tag, color, msg):
        if not self.enabled: return
        line = f"{self.COLORS[color]}{self._ts()}[{tag:>6s}]{self.COLORS['reset']} {msg}"
        print(line)
        self.buffer.append(line)

    def info(self, msg):   self._write('INFO', 'info', msg)
    def calc(self, msg):   self._write('CALC', 'calc', msg)
    def warn(self, msg):   self._write('WARN', 'warn', msg)
    def err(self, msg):    self._write(' ERR', 'err', msg)
    def ok(self, msg):     self._write('  OK', 'ok', msg)

    def quip(self, key, value, unit=''):
        """Log a constant/result with its associated humor tag."""
        q = self.QUIPS.get(key, '')
        msg = f"{key} = {value}{unit}  {self.COLORS['dim']}{q}{self.COLORS['reset']}"
        self._write('CALC', 'calc', msg)

    def header(self, title):
        if not self.enabled: return
        bar = '═' * 78
        print(f"\n{self.COLORS['header']}{bar}")
        print(f"  {title}")
        print(f"{bar}{self.COLORS['reset']}")

    def divider(self):
        if self.enabled: print(self.COLORS['dim'] + '─'*78 + self.COLORS['reset'])

    def close(self):
        if self.enabled:
            print(f"\n{self.COLORS['dim']}[CONSOLE CLOSE] {len(self.buffer)} lines logged · T+{time.time()-self.t0:.2f}s{self.COLORS['reset']}")

console = Console()

# ══════════════════════════════════════════════════════════════════════════════
# PLOTTING THEME — NASA-grade, dark or light
# ══════════════════════════════════════════════════════════════════════════════
DARK_THEME = {
    'fig_bg': '#0a0c10', 'axes_bg': '#141821', 'axes_edge': '#242a38',
    'text': '#e8ecf2', 'text_dim': '#a0a8b8', 'muted': '#606878', 'grid': '#1e2330',
    'accent1': '#4fc3f7', 'accent2': '#f97316', 'accent3': '#a78bfa',
    'accent4': '#34d399', 'accent5': '#ef4444', 'accent_gold': '#fbbf24',
}
LIGHT_THEME = {
    'fig_bg': '#f5f5f0', 'axes_bg': '#ffffff', 'axes_edge': '#d8dbe0',
    'text': '#0a1628', 'text_dim': '#3a4558', 'muted': '#6a7585', 'grid': '#e5e8ed',
    'accent1': '#0284c7', 'accent2': '#ea580c', 'accent3': '#7c3aed',
    'accent4': '#059669', 'accent5': '#dc2626', 'accent_gold': '#d97706',
}

def apply_theme(theme_dict):
    t = theme_dict
    plt.rcParams.update({
        'figure.facecolor':   t['fig_bg'],
        'axes.facecolor':     t['axes_bg'],
        'axes.edgecolor':     t['axes_edge'],
        'axes.labelcolor':    t['text_dim'],
        'axes.titlecolor':    t['text'],
        'axes.grid':          True,
        'grid.color':         t['grid'],
        'grid.linewidth':     0.6,
        'grid.alpha':         0.7,
        'xtick.color':        t['muted'],
        'ytick.color':        t['muted'],
        'text.color':         t['text'],
        'font.family':        'monospace',
        'font.size':          9,
        'axes.titlesize':     10,
        'axes.labelsize':     9,
        'legend.fontsize':    7.5,
        'legend.framealpha':  0.15,
        'legend.facecolor':   t['axes_bg'],
        'legend.edgecolor':   t['axes_edge'],
        'axes.linewidth':     0.8,
        'xtick.major.width':  0.8,
        'ytick.major.width':  0.8,
        'lines.linewidth':    2.0,
        'lines.antialiased':  True,
        'savefig.facecolor':  t['fig_bg'],
        'savefig.edgecolor':  'none',
        'savefig.bbox':       'tight',
        'savefig.pad_inches': 0.2,
    })

def nasa_decorate(ax, title=None, xlabel=None, ylabel=None, theme=None):
    """Apply NASA-publication-style decoration."""
    t = theme
    if title: ax.set_title(title, loc='left', fontweight='bold', color=t['accent1'], pad=12)
    if xlabel: ax.set_xlabel(xlabel, color=t['text_dim'], labelpad=6)
    if ylabel: ax.set_ylabel(ylabel, color=t['text_dim'], labelpad=6)
    for spine in ['top', 'right']:
        ax.spines[spine].set_visible(False)
    for spine in ['bottom', 'left']:
        ax.spines[spine].set_color(t['axes_edge'])

# ══════════════════════════════════════════════════════════════════════════════
# INDIVIDUAL PLOT GENERATORS
# Each takes (params, theme, outdir) and returns (filename, error_pct_or_None)
# ══════════════════════════════════════════════════════════════════════════════
def plot_fT(params, theme, outdir, dpi):
    """Mixture-weighted f(T) decomposition."""
    mixture = params['mixture']
    n = params['n']
    T_range = np.linspace(200, 20000, 300)

    f_total = []
    f_therm = []
    f_rad_arr = []
    f_diss_arr = []
    for T in T_range:
        fm = f_mix(mixture, T, n, enable_rad=True, enable_diss=True)
        f_total.append(fm['total'])
        f_therm.append(fm['thermal'])
        f_rad_arr.append(fm['radiative'])
        f_diss_arr.append(fm['dissociation'])

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    ax.semilogy(T_range, f_total,   color=theme['accent4'], lw=2.8, label='f_total (mixture + rad + diss)')
    ax.semilogy(T_range, f_therm,   color=theme['accent1'], lw=1.8, ls='--', label='Σxᵢfᵢ(T) thermal')
    ax.semilogy(T_range, f_rad_arr, color=theme['accent5'], lw=1.8, ls=':',  label='f_rad (Planck)')
    ax.semilogy(T_range, f_diss_arr,color=theme['accent2'], lw=1.8, ls='-.', label='f_diss (AB⇌2A)')

    # Regime shading
    ax.axvspan(200, 500, alpha=0.04, color=theme['accent1'])
    ax.axvspan(500, 2000, alpha=0.04, color=theme['accent4'])
    ax.axvspan(2000, 8000, alpha=0.04, color=theme['accent2'])
    ax.axvspan(8000, 20000, alpha=0.04, color=theme['accent5'])

    # Regime labels
    for T_mid, label, col in [(350, 'Classical', theme['accent1']),
                                (1250, 'V1 Paper', theme['accent4']),
                                (5000, 'V2 Ext.', theme['accent2']),
                                (14000, 'V2 Plasma', theme['accent5'])]:
        ax.text(T_mid, max(f_total)*0.7, label, fontsize=7, ha='center',
                color=col, alpha=0.8)

    nasa_decorate(ax,
        title=f'f_mix(T) — Effective Degrees of Freedom · {params["label"]}',
        xlabel='Temperature T [K]', ylabel='Effective DOF (log scale)', theme=theme)
    ax.legend(loc='upper left')
    ax.set_ylim(0.8, max(max(f_total), 10)*2)

    fname = f'{outdir}/fig_01_fT_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_aT(params, theme, outdir, dpi):
    """Attraction parameter a_mix(T)."""
    mixture = params['mixture']
    T_range = np.linspace(200, 20000, 300)

    a_mix_arr = [a_mixture(mixture, T) for T in T_range]
    a_ref = a_mix_arr[0]
    a_norm = [a/a_ref for a in a_mix_arr]

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    ax.plot(T_range, a_norm, color=theme['accent4'], lw=2.8, label='a_mix(T)/a_mix(200K)')

    palette = [theme['accent1'], theme['accent2'], theme['accent3'], theme['accent5']]
    for i, (sp, x, nm) in enumerate(mixture):
        a_sp = [a_species(sp, T)/a_ref for T in T_range]
        ax.plot(T_range, a_sp, color=palette[i % len(palette)], lw=1.5, ls='--',
                label=f'a_{nm}(T) normalized')

    nasa_decorate(ax,
        title=f'Attraction Parameter a(T) · Redlich-Kwong Scaling',
        xlabel='Temperature T [K]', ylabel='Normalized a(T)/a(200K)', theme=theme)
    ax.legend(loc='upper right')

    fname = f'{outdir}/fig_02_aT_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_muT(params, theme, outdir, dpi):
    """Viscosity μ_mix(T) — Sutherland mixture."""
    mixture = params['mixture']
    T_range = np.linspace(200, 20000, 300)

    mu_mix_arr = [mu_mixture(mixture, T) for T in T_range]

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    ax.semilogy(T_range, mu_mix_arr, color=theme['accent4'], lw=2.8, label='μ_mix = Σxᵢμᵢ(T)')

    palette = [theme['accent1'], theme['accent2'], theme['accent3']]
    for i, (sp, x, nm) in enumerate(mixture):
        mu_sp = [mu_species(sp, T) for T in T_range]
        ax.semilogy(T_range, mu_sp, color=palette[i % len(palette)], lw=1.5, ls='--',
                    label=f'μ_{nm}(T)')

    nasa_decorate(ax,
        title=f'Dynamic Viscosity μ(T) · Sutherland Law (Mixture)',
        xlabel='Temperature T [K]', ylabel='μ [Pa·s] (log scale)', theme=theme)
    ax.legend(loc='lower right')

    fname = f'{outdir}/fig_03_muT_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_Ia(params, theme, outdir, dpi):
    """Iₐ(T) at multiple n values."""
    mixture = params['mixture']
    T_range = np.linspace(200, 20000, 300)
    n_samples = [(1e21, theme['accent1']), (1e22, theme['accent4']),
                 (1e24, theme['accent2']), (1e25, theme['accent5'])]

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    for n, col in n_samples:
        ia_arr = [Ia_number(mixture, T, n, enable_rad=(T>=8000), enable_diss=(T>=2000))
                  for T in T_range]
        ax.semilogy(T_range, ia_arr, color=col, lw=2.3, label=f'n = {n:.0e} m⁻³')

    ax.axhline(1e-2, color=theme['accent_gold'], lw=1.2, ls=':', label='Threshold (1e-2)')

    nasa_decorate(ax,
        title=f'Intermolecular Activity Number Iₐ(T) · Paper Eq. 16',
        xlabel='Temperature T [K]', ylabel='Iₐ (log scale)', theme=theme)
    ax.legend(loc='upper right')

    fname = f'{outdir}/fig_04_Ia_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_Pr(params, theme, outdir, dpi):
    """P_IM(r, T) — explicit spacing dependence."""
    mixture = params['mixture']
    r_range = np.logspace(-10, -6, 200)
    Ts = [(500, theme['accent1']), (2000, theme['accent4']),
          (8000, theme['accent2']), (15000, theme['accent5'])]

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    for T, col in Ts:
        P_arr = [abs(P_IM_r(mixture, T, r)) for r in r_range]
        ax.loglog(r_range*1e9, P_arr, color=col, lw=2.3, label=f'T = {T} K')

    nasa_decorate(ax,
        title=f'Intermolecular Pressure |P_IM(r,T)| · n(r)=xᵢ/[(4/3)πr³]',
        xlabel='Intermolecular spacing r [nm]', ylabel='|P_IM| [Pa]', theme=theme)
    ax.legend(loc='upper right')

    fname = f'{outdir}/fig_05_Pr_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_dissociation(params, theme, outdir, dpi):
    """Dissociation α(T) for each diatomic species."""
    mixture = params['mixture']
    T_range = np.linspace(200, 20000, 300)
    palette = [theme['accent1'], theme['accent2'], theme['accent3'],
               theme['accent5'], theme['accent4']]

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    ci = 0
    for sp, x, nm in mixture:
        if sp.get('D_diss') is None: continue
        alpha_arr = [diss_fraction(sp, T) for T in T_range]
        ax.plot(T_range, alpha_arr, color=palette[ci % len(palette)], lw=2.5,
                label=f'α_{nm}  (D = {sp["D_diss"]/1e3:.0f} kJ/mol)')
        ci += 1
    ax.axhline(0.5, color=theme['muted'], lw=1, ls=':', alpha=0.6)
    ax.axhline(0.01, color=theme['muted'], lw=1, ls=':', alpha=0.6)

    nasa_decorate(ax,
        title=f'Molecular Dissociation Fraction α(T) · AB ⇌ 2A',
        xlabel='Temperature T [K]', ylabel='Dissociation fraction α', theme=theme)
    ax.set_ylim(-0.02, 1.05)
    ax.legend(loc='lower right')

    fname = f'{outdir}/fig_06_alpha_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_gradient_decomp(params, theme, outdir, dpi):
    """∇P_IM density vs temperature coupling."""
    mixture = params['mixture']
    n = params['n']
    T_range = np.linspace(500, 20000, 200)

    dens_arr = []
    temp_arr = []
    for T in T_range:
        d, t = gradPIM_components(mixture, T, n)
        dens_arr.append(d)
        temp_arr.append(t)

    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=dpi)
    ax.semilogy(T_range, dens_arr, color=theme['accent1'], lw=2.5,
                label='Density-coupled: 2a(T)·n·∇n')
    ax.semilogy(T_range, temp_arr, color=theme['accent2'], lw=2.5, ls='--',
                label='Temp-coupled: n²·(da/dT)·∇T')

    nasa_decorate(ax,
        title=f'∇P_IM Decomposition · Paper Eq. 9/26',
        xlabel='Temperature T [K]', ylabel='|∇P_IM| component [Pa/m]', theme=theme)
    ax.legend(loc='upper right')

    fname = f'{outdir}/fig_07_gradPIM_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_heat_flux_sweep(params, theme, outdir, dpi):
    """q_stag vs Mach — model vs NASA reference."""
    mixture = params['mixture']
    Tinf = params['T_inf']
    n = params['n']
    Rn = params['Rn']
    p_data = params['planet_data']

    M_range = np.linspace(1, 60, 150)
    q_model = []
    for M in M_range:
        res = stagnation_heat_flux(mixture, M, Tinf, n, Rn, beta=8.0)
        q_model.append(res['q_total']/1e6)

    fig, ax = plt.subplots(figsize=(11, 6.5), dpi=dpi)
    ax.semilogy(M_range, q_model, color=theme['accent1'], lw=2.8,
                label='Extended NS (auto-routed)')

    # NASA reference point
    ref = p_data['reference_mission']
    ax.scatter([ref['Mach']], [ref['peak_q_MW_m2']],
               color=theme['accent5'], s=180, marker='*', zorder=10,
               edgecolor='white', linewidth=1.5,
               label=f'{ref["name"]} (NASA) — {ref["peak_q_MW_m2"]} MW/m²')

    # Current point
    res_cur = stagnation_heat_flux(mixture, ref['Mach'], Tinf, n, Rn, beta=8.0)
    ax.scatter([ref['Mach']], [res_cur['q_total']/1e6],
               color=theme['accent4'], s=120, marker='o', zorder=9,
               edgecolor='white', linewidth=1.2,
               label=f'Model @ M{ref["Mach"]} — {res_cur["q_total"]/1e6:.2f} MW/m²')

    # Error annotation
    q_ref = ref['peak_q_MW_m2']
    err = abs(res_cur['q_total']/1e6 - q_ref) / q_ref * 100
    err_col = theme['accent4'] if err < 10 else theme['accent_gold'] if err < 30 else theme['accent2'] if err < 50 else theme['accent5']
    ax.text(0.02, 0.97, f'ERROR vs NASA: {err:.2f}%',
            transform=ax.transAxes, fontsize=10, fontweight='bold',
            color=err_col, verticalalignment='top',
            bbox=dict(boxstyle='round,pad=0.5', facecolor=theme['axes_bg'],
                      edgecolor=err_col, linewidth=1.5))

    nasa_decorate(ax,
        title=f'Stagnation Heat Flux vs Mach · {params["label"]} · vs NASA Reference',
        xlabel='Mach Number', ylabel='q_total [MW/m²] (log)', theme=theme)
    ax.legend(loc='lower right')

    fname = f'{outdir}/fig_08_qflux_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, err

def plot_poiseuille(params, theme, outdir, dpi):
    """Poiseuille velocity with Iₐ correction."""
    mixture = params['mixture']
    n = params['n']
    y = np.linspace(-1, 1, 200)
    Ts = [(500, theme['accent1']), (2000, theme['accent4']),
          (8000, theme['accent2']), (15000, theme['accent5'])]

    fig, ax = plt.subplots(figsize=(9, 7), dpi=dpi)
    ax.plot(1 - y**2, y, color=theme['muted'], lw=2, ls='--', label='Classical NS (Iₐ=0)')
    for T, col in Ts:
        ia_val = Ia_number(mixture, T, n, enable_rad=(T>=8000), enable_diss=(T>=2000))
        u = (1 - y**2) * (1 + ia_val * 2.5 * (1 - y**2))
        ax.plot(u, y, color=col, lw=2.3, label=f'T={T}K, Iₐ={ia_val:.2e}')

    nasa_decorate(ax,
        title='Planar Poiseuille Flow · Iₐ-corrected Velocity Profile',
        xlabel='u / u_max', ylabel='y / H (wall-normal)', theme=theme)
    ax.legend(loc='center right')
    ax.set_ylim(-1.05, 1.05)

    fname = f'{outdir}/fig_09_poiseuille_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

def plot_Ia_parameter_space(params, theme, outdir, dpi):
    """Iₐ(n, T) 2D contour with entry trajectory."""
    mixture = params['mixture']
    T_grid = np.logspace(np.log10(300), np.log10(20000), 80)
    n_grid = np.logspace(18, 26, 80)
    TT, NN = np.meshgrid(T_grid, n_grid)

    IA = np.zeros_like(TT)
    for i, n in enumerate(n_grid):
        for j, T in enumerate(T_grid):
            IA[i,j] = Ia_number(mixture, T, n, enable_rad=(T>=8000), enable_diss=(T>=2000))
    IA_log = np.log10(np.clip(IA, 1e-14, 1e2))

    fig, ax = plt.subplots(figsize=(10, 7), dpi=dpi)
    cf = ax.contourf(TT, NN, IA_log, levels=24, cmap='RdYlGn_r')
    ax.contour(TT, NN, IA_log, levels=[-2], colors='white', linewidths=1.5)

    # Entry trajectory for the planet
    p_data = params['planet_data']
    ref = p_data['reference_mission']
    T_traj = np.linspace(300, min(ref['V_entry']/3, 18000), 20)
    n_traj = np.logspace(np.log10(p_data['n_inf']*0.1),
                         np.log10(p_data['n_inf']*3), 20)
    ax.plot(T_traj, n_traj, color='white', lw=2.5, marker='o', ms=5,
            label=f'{ref["name"]} entry trajectory')

    ax.set_yscale('log')
    nasa_decorate(ax,
        title=f'Iₐ(n,T) Parameter Space · {params["label"]}',
        xlabel='Temperature T [K]', ylabel='Number density n [m⁻³]', theme=theme)
    cbar = plt.colorbar(cf, ax=ax, label='log₁₀(Iₐ)', pad=0.02)
    cbar.ax.tick_params(colors=theme['muted'])
    cbar.set_label('log₁₀(Iₐ)', color=theme['text_dim'])
    ax.legend(loc='lower right')

    fname = f'{outdir}/fig_10_paramspace_{params["key"]}.png'
    plt.savefig(fname, dpi=dpi)
    plt.close()
    console.ok(f'Saved {fname}')
    return fname, None

# ══════════════════════════════════════════════════════════════════════════════
# MAIN ANALYSIS PIPELINE
# ══════════════════════════════════════════════════════════════════════════════
def run_analysis(planet_key, theme_name='dark', dpi_override=None, outdir=None):
    """Run full analysis pipeline for given planet, emit all plots + summary."""

    # Theme
    theme = DARK_THEME if theme_name == 'dark' else LIGHT_THEME
    apply_theme(theme)

    # Console banner
    console.header(f'EXTENDED NS ANALYSIS · {PLANETS[planet_key]["label"].upper()}')
    console.info(f'Theme: {theme_name}')
    console.info(f'Loading physics library...')
    console.ok('Physics library ready')

    # Params
    p = PLANETS[planet_key]
    mixture = planet_mixture(planet_key)
    ref = p['reference_mission']

    params = {
        'key':          planet_key,
        'label':        p['label'],
        'mixture':      mixture,
        'T_inf':        p['T_inf'],
        'n':            p['n_inf'],
        'Mach':         ref['Mach'],
        'Rn':           ref['Rn_m'],
        'planet_data':  p,
    }

    console.info(f'Mixture composition:')
    for sp, x, nm in mixture:
        console.info(f'    {nm:4s}  x = {x:.4f}')

    # Run main heat flux calculation
    console.divider()
    console.info('Running primary stagnation heat flux calculation...')
    res = stagnation_heat_flux(mixture, ref['Mach'], p['T_inf'], p['n_inf'],
                                ref['Rn_m'], beta=8.0)

    console.quip('la', f"{res['V']:.1f}", ' m/s')  # velocity humor tag
    console.quip('rho', f"{res['rho']:.3e}", ' kg/m³')
    console.calc(f'T_shock = {res["T_stag"]:.1f} K  →  Model: {res["model_label"]}')
    console.calc(f'α, β intermediate params absorbed into formulation [see paper]')
    console.quip('alpha', 'absorbed into a(T)/N_A²')
    console.quip('beta',  'absorbed into ∇n field')

    # Compute f_mix for quip
    fm = f_mix(mixture, res['T_stag'], p['n_inf'],
               enable_rad=res['use_rad'], enable_diss=res['use_diss'])
    console.quip('fT', f"{fm['total']:.3f}")
    if fm['total'] > 20:
        console.calc('  → vibrational modes engaged, dissociation active')
    console.quip('Ia', f"{res['Ia']:.3e}")

    console.divider()
    console.calc(f'q_conv  = {res["q_conv"]/1e6:.3e} MW/m²')
    console.calc(f'q_rad   = {res["q_rad"]/1e6:.3e} MW/m²')
    console.calc(f'q_diss  = {res["q_diss"]/1e6:.3e} MW/m²')
    console.calc(f'q_TOTAL = {res["q_total"]/1e6:.3e} MW/m²  ← model prediction')
    console.divider()

    # Error vs NASA
    q_ref = ref['peak_q_MW_m2']
    err = abs(res['q_total']/1e6 - q_ref) / q_ref * 100
    err_tag = 'EXCELLENT' if err < 10 else 'GOOD' if err < 30 else 'MODERATE' if err < 50 else 'POOR'
    (console.ok if err < 30 else console.warn)(
        f'vs {ref["name"]} (NASA, {q_ref} MW/m²):  ERROR = {err:.2f}%  [{err_tag}]')

    # Determine DPI: 600 for T > 1000 K, else 150
    dpi = dpi_override if dpi_override else (600 if res['T_stag'] > 1000 else 150)
    console.info(f'Plot DPI: {dpi} (T_shock = {res["T_stag"]:.0f} K)')

    # Output directory
    if outdir is None:
        outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                              f'ns_plots_{planet_key}')
    os.makedirs(outdir, exist_ok=True)
    console.info(f'Output directory: {outdir}')

    # Generate plots
    console.divider()
    console.header('GENERATING PLOTS')

    plot_funcs = [
        plot_fT, plot_aT, plot_muT, plot_Ia, plot_Pr,
        plot_dissociation, plot_gradient_decomp, plot_heat_flux_sweep,
        plot_poiseuille, plot_Ia_parameter_space,
    ]
    outputs = []
    for pf in plot_funcs:
        fname, sub_err = pf(params, theme, outdir, dpi)
        outputs.append(fname)

    console.divider()
    console.ok(f'Generated {len(outputs)} plots at {dpi} DPI')

    return res, outputs, err

# ══════════════════════════════════════════════════════════════════════════════
# CLI / MAIN
# ══════════════════════════════════════════════════════════════════════════════
def main():
    parser = argparse.ArgumentParser(description='Extended NS Hypersonic Analysis')
    parser.add_argument('--planet', default=None,
                        choices=list(PLANETS.keys()),
                        help='Planet template (default: interactive prompt)')
    parser.add_argument('--dpi', type=int, default=None,
                        help='Override auto DPI selection')
    parser.add_argument('--outdir', default=None, help='Output directory')
    parser.add_argument('--validate', action='store_true',
                        help='Run validation suite only')
    parser.add_argument('--no-console', action='store_true',
                        help='Disable console output')
    parser.add_argument('--all', action='store_true',
                        help='Run all planets sequentially')
    args = parser.parse_args()

    if args.no_console:
        console.enabled = False

    # Validation mode
    if args.validate:
        console.header('VALIDATION SUITE')
        passed, total, details = validate()
        for name, ok, detail in details:
            if ok: console.ok(f'{name:55s} {detail}')
            else:  console.err(f'{name:55s} {detail}')
        console.divider()
        if passed == total:
            console.ok(f'RESULT: {passed}/{total} tests passed')
        else:
            console.warn(f'RESULT: {passed}/{total} tests passed')
        console.close()
        return

    # Interactive prompt if no planet given
    planet_keys = list(PLANETS.keys())

    if args.all:
        planets_to_run = planet_keys
        console.header('RUNNING ALL PLANETS')
    else:
        if args.planet is None:
            print('\n' + '═'*60)
            print('  EXTENDED NS — PLANET SELECTOR')
            print('═'*60)
            for i, pk in enumerate(planet_keys):
                print(f'  [{i+1:2d}]  {pk:20s}  {PLANETS[pk]["label"]}')
            print('═'*60)
            while True:
                try:
                    choice = input('\n  Enter number (1-{}) or planet name: '.format(len(planet_keys))).strip()
                    if choice.isdigit():
                        idx = int(choice) - 1
                        if 0 <= idx < len(planet_keys):
                            selected_planet = planet_keys[idx]
                            break
                        else:
                            print(f'  Enter a number between 1 and {len(planet_keys)}')
                    elif choice in planet_keys:
                        selected_planet = choice
                        break
                    else:
                        print(f'  Not recognised. Try a number or one of: {", ".join(planet_keys)}')
                except (KeyboardInterrupt, EOFError):
                    print('\n  Cancelled.')
                    return
        else:
            selected_planet = args.planet

        planets_to_run = [selected_planet]

    theme = 'dark'  # NASA-grade dark theme always

    # Run analysis for each selected planet
    for pk in planets_to_run:
        console.header(f'RUNNING: {PLANETS[pk]["label"].upper()}')
        res, outputs, err = run_analysis(pk, theme, args.dpi, args.outdir)
        console.header(f'COMPLETE: {PLANETS[pk]["label"]}')
        console.info(f'Model: {res["model_label"]}')
        console.info(f'Error vs NASA: {err:.2f}%')
        console.info(f'Plots: {len(outputs)} files')
        if len(planets_to_run) > 1:
            console.divider()

    console.close()

if __name__ == '__main__':
    main()
