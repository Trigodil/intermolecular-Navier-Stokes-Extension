"""
NUCLEAR PATHOLOGICAL INTEGRAL STRESS TEST

Inputs designed to destroy:
1. factorial(factorial(n)) * integral
2. Gamma function explosions  
3. Nested integrals with divergent inner
4. Self-referential integral (integral of Ia itself)
5. Stirling's monster: n! ~ sqrt(2πn)(n/e)^n inside integral
6. Ramanujan's summation: 1+2+3+... = -1/12 as input
7. Riemann zeta at s=1 (harmonic series, diverges to infinity)
8. Integral of e^(x^x) from 0 to infinity (grows insanely fast)
9. Double factorial nested: (2n-1)!! inside cos inside integral
10. The absolute final boss: all of the above multiplied together
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate, special
from scipy.special import gamma, factorial
import warnings
warnings.filterwarnings("ignore")

BG         = "white"
AXIS_COLOR = "black"
TITLE_SIZE = 15
LABEL_SIZE = 13
TICK_SIZE  = 11
LEGEND_SIZE= 10
LW         = 2.5
DPI        = 600

C1="#1a7abf"; C2="#e05c00"; C3="#7c3aed"
C4="#059669"; C5="#dc2626"; C6="#f59e0b"
C7="#ec4899"; C8="#06b6d4"; GREY="#444444"

def style(ax):
    ax.set_facecolor(BG)
    for sp in ax.spines.values():
        sp.set_linewidth(2.0); sp.set_color(AXIS_COLOR)
    ax.tick_params(axis="both", which="major", width=1.8, length=7,
                   color=AXIS_COLOR, labelcolor=AXIS_COLOR,
                   labelsize=TICK_SIZE, direction="in", top=True, right=True)
    ax.grid(False)

def leg(ax, **kw):
    l = ax.legend(fontsize=LEGEND_SIZE, framealpha=1.0,
                  edgecolor="#aaaaaa", facecolor="white", **kw)
    for t in l.get_texts(): t.set_color(AXIS_COLOR)
    return l

def save(fig, name):
    fig.savefig(f"{name}.png",
                dpi=DPI, bbox_inches="tight", facecolor=BG)
    plt.close(fig)
    print(f"  Saved: {name}.png")

# ─── Constants ────────────────────────────────────────────────────────────────
kB=1.380649e-23; NA=6.02214076e23; R=8.314
M_air=0.02897; a0_air=0.1361; Tc_air=132.5; ThetaV=3374.0
n_earth=2.7e25; T_earth=293.0

def a_T(T):
    T = np.array(T, dtype=complex)
    return a0_air * np.sqrt(Tc_air / (T + 1e-300))

def f_T(T):
    T  = np.atleast_1d(np.float64(np.real(T)))
    T  = np.clip(T, 1e-10, 1e15)
    x  = np.clip(ThetaV/T, 0, 500)
    vib= 2*x**2*np.exp(x)/(np.exp(x)-1+1e-300)**2
    return 5.0 + np.where(x>100, 0.0, vib)

def Ia(n, T):
    """The unbreakable equation"""
    n   = np.array(n, dtype=complex)
    T   = np.array(T, dtype=complex)
    f   = f_T(T)
    num = a_T(T) * n**2 / NA**2
    den = (f/2) * n * kB * T
    res = num / (den + 1e-300j)
    if np.ndim(res) == 0:
        return complex(res)
    return res

def Ia_scalar(n, T):
    return complex(np.squeeze(Ia(n, T)))

def safe_report(name, n_val, T_val, note=""):
    try:
        result = Ia_scalar(n_val, T_val)
        re, im = float(np.real(result)), float(np.imag(result))
        status = "✓ SURVIVED"
        val_str = f"Re={re:.3e}  Im={im:.3e}"
    except (OverflowError, ZeroDivisionError, ValueError) as e:
        status = f"✗ BROKE: {type(e).__name__}"
        val_str = "---"
    except Exception as e:
        status = f"? {type(e).__name__}"
        val_str = "---"
    print(f"  {name:<45} {val_str:<35} {status}  {note}")
    return status, val_str

print("="*90)
print("NUCLEAR PATHOLOGICAL STRESS TEST — L_a Constant vs Pure Mathematics")
print("="*90)
print()

results = {}

#TEST 1: n! where n is large
print(" FACTORIAL INPUTS ")

# factorial(10)
n1 = float(special.factorial(10, exact=True)) * n_earth
s, v = safe_report("n = 10! × n₀", n1, T_earth, f"(n = {n1:.2e})")
results["10! × n₀"] = (s, v)

# factorial(20)
n2 = float(special.factorial(20, exact=True)) * n_earth
s, v = safe_report("n = 20! × n₀", n2, T_earth, f"(n = {n2:.2e})")
results["20! × n₀"] = (s, v)

# factorial inside factorial: (5!)! = 120! 
n3 = float(special.factorial(float(special.factorial(5, exact=True)), exact=False))
s, v = safe_report("n = (5!)! = 120!  (astronomical)", n3*n_earth, T_earth)
results["(5!)!"] = (s, v)

# Gamma(1/2) = sqrt(pi) — fractional factorial
n4 = float(gamma(0.5)) * n_earth
s, v = safe_report("n = Γ(1/2)·n₀ = √π·n₀", n4, T_earth)
results["Γ(1/2)·n₀"] = (s, v)

# Gamma(-1/2)  — negative gamma
n5 = float(gamma(-0.5)) * n_earth
s, v = safe_report("n = Γ(-1/2)·n₀ = -2√π·n₀  (negative!)", n5, T_earth)
results["Γ(-1/2)·n₀"] = (s, v)

# TEST 2: FACTORIAL INSIDE INTEGRAL
print()
print("FACTORIAL INSIDE INTEGRAL")

# intergral^5 n! × e^(-x) dx  where n=floor(x)  (sum of factorials weighted by exp)
def integrand_fact_exp(x):
    n_floor = int(np.floor(x))
    return float(special.factorial(n_floor, exact=False)) * np.exp(-x)

try:
    I_fe, _ = integrate.quad(integrand_fact_exp, 0, 10, limit=500)
    n_fe = I_fe * n_earth
    s, v = safe_report("∫₀¹⁰ ⌊x⌋! × e^(-x) dx as density", n_fe, T_earth,
                       f"integral={I_fe:.4e}")
    results["∫⌊x⌋!e^(-x)dx"] = (s, v)
except Exception as e:
    print(f"  Integral evaluation failed: {e}")

# intergral^3 Γ(x+1) × cos(πx) dx  (gamma oscillating)
def integrand_gamma_cos(x):
    try:
        return float(gamma(x+1)) * np.cos(np.pi*x)
    except:
        return 0.0

try:
    I_gc, _ = integrate.quad(integrand_gamma_cos, 0, 3, limit=500)
    n_gc = I_gc * n_earth
    s, v = safe_report("∫₀³ Γ(x+1)cos(πx) dx as density", n_gc, T_earth,
                       f"integral={I_gc:.4e}")
    results["∫Γ(x+1)cos(πx)dx"] = (s, v)
except Exception as e:
    print(f"  Integral evaluation failed: {e}")

# intergral^∞ x^n × e^(-x^2) dx with factorial outside: n! × integral
def integrand_gaussian_n(x, power=5):
    return x**power * np.exp(-x**2)

try:
    I_gn, _ = integrate.quad(integrand_gaussian_n, 0, np.inf, args=(5,))
    n_fact_int = float(special.factorial(5, exact=True)) * I_gn * n_earth
    s, v = safe_report("5! × ∫₀^∞ x⁵e^(-x²) dx as density", n_fact_int, T_earth,
                       f"val={n_fact_int:.3e}")
    results["5!×∫x⁵e^(-x²)dx"] = (s, v)
except Exception as e:
    print(f"  Failed: {e}")

# TEST 3: RAMANUJAN / ZETA SPECIAL VALUES 
print()
print(" RAMANUJAN / RIEMANN ZETA INPUTS")

# Ramanujan: 1+2+3+... = -1/12 (zeta regularization)
n_ram = (-1/12) * n_earth
s, v = safe_report("n = (-1/12)·n₀  (Ramanujan sum 1+2+3+...)", n_ram, T_earth)
results["Ramanujan -1/12"] = (s, v)

# ζ(2) = π²/6 
n_zeta2 = (np.pi**2/6) * n_earth
s, v = safe_report("n = (π²/6)·n₀  [ζ(2), Basel problem]", n_zeta2, T_earth)
results["ζ(2)=π²/6"] = (s, v)

# ζ(0) = -1/2
n_zeta0 = (-0.5) * n_earth
s, v = safe_report("n = (-1/2)·n₀  [ζ(0)]", n_zeta0, T_earth)
results["ζ(0)=-1/2"] = (s, v)

# ζ(-1) = -1/12
n_zetam1 = (-1/12) * n_earth
s, v = safe_report("n = (-1/12)·n₀  [ζ(-1)]", n_zetam1, T_earth)
results["ζ(-1)=-1/12"] = (s, v)

#TEST 4: NESTED INTEGRALS
print()
print("NESTED INTEGRALS")

# intergral^1 (intergral^x e^(t²) dt) × factorial(floor(x*10)) dx
def inner_integral(x):
    try:
        result, _ = integrate.quad(lambda t: np.exp(t**2), 0, x, limit=100)
        return result * float(special.factorial(int(np.floor(x*5)), exact=False))
    except:
        return 0.0

try:
    I_nested, _ = integrate.quad(inner_integral, 0, 1, limit=100)
    s, v = safe_report("∫₀¹ [∫₀ˣ e^(t²)dt × ⌊5x⌋!] dx", I_nested*n_earth, T_earth,
                       f"integral={I_nested:.4e}")
    results["Nested ∫e^t²×⌊x⌋!"] = (s, v)
except Exception as e:
    print(f"  Nested integral failed: {e}")

#TEST 5: e^(x^x) INTEGRAL
print()
print(" e^(x^x) TERRITORY")

# intergral^3 e^(x^x) dx 
def integrand_xx(x):
    try:
        val = np.exp(x * np.log(max(x, 1e-10)))  # x^x = e^(x ln x)
        return np.exp(val) if val < 700 else np.exp(700)
    except:
        return 0.0

try:
    I_xx, _ = integrate.quad(integrand_xx, 0.01, 2.5, limit=500)
    s, v = safe_report("∫₀^2.5 e^(x^x) dx as density", I_xx*n_earth, T_earth,
                       f"integral={I_xx:.4e}")
    results["∫e^(x^x)dx"] = (s, v)
except Exception as e:
    print(f"  Failed: {e}")

# TEST 6: DOUBLE FACTORIAL
print()
print("── DOUBLE FACTORIAL INSIDE INTEGRAL ─────────────────────────────────────────")

# intergral^5 (2n-1)!! × e^(-x) dx where n=floor(x)
def double_fact_integrand(x):
    n_val = max(1, int(np.floor(x)))
    # (2n-1)!! = 1×3×5×...×(2n-1)
    df = 1.0
    for k in range(1, 2*n_val, 2):
        df *= k
    return df * np.exp(-x)

try:
    I_df, _ = integrate.quad(double_fact_integrand, 0, 8, limit=500)
    s, v = safe_report("∫₀⁸ (2⌊x⌋-1)!! × e^(-x) dx", I_df*n_earth, T_earth,
                       f"integral={I_df:.4e}")
    results["∫(2n-1)!!e^(-x)dx"] = (s, v)
except Exception as e:
    print(f"  Failed: {e}")

# TEST 7: ORIGINAL PATHOLOGICAL + FACTORIAL OUTSIDE
print()
print("ORIGINAL + FACTORIAL MULTIPLIER ")

# Original: e^intergral ln(π^(e^x))cos(x^i)dx  with n! outside
def orig_integrand_r(x):
    if x <= 0: return 0.0
    xi = np.exp(1j * np.log(x))
    return float(np.real(np.exp(x) * np.log(np.pi) * np.cos(xi)))

def orig_integrand_i(x):
    if x <= 0: return 0.0
    xi = np.exp(1j * np.log(x))
    return float(np.imag(np.exp(x) * np.log(np.pi) * np.cos(xi)))

try:
    from scipy.integrate import cumulative_trapezoid
    x_pts  = np.linspace(0.01, 4, 1000)
    ir_arr = np.array([orig_integrand_r(x) for x in x_pts])
    ii_arr = np.array([orig_integrand_i(x) for x in x_pts])
    cum_r  = cumulative_trapezoid(ir_arr, x_pts, initial=0)
    cum_i  = cumulative_trapezoid(ii_arr, x_pts, initial=0)
    path_val = np.exp(cum_r[-1] + 1j*cum_i[-1])

    # Now multiply by 7! outside
    fact7 = float(special.factorial(7, exact=True))
    n_monster = fact7 * path_val * n_earth
    s, v = safe_report("7! × e^∫ln(π^(e^x))cos(xⁱ)dx", n_monster, T_earth,
                       f"7!={fact7:.0f}")
    results["7!×original"] = (s, v)

    # AND factorial inside: ∫ ⌊e^x⌋! × ln(π^(e^x)) × cos(x^i) dx
    def monster_integrand(x):
        if x <= 0: return 0.0+0j
        xi   = np.exp(1j*np.log(max(x, 1e-10)))
        n_fl = min(int(np.floor(np.exp(x))), 12)
        fact = float(special.factorial(n_fl, exact=True))
        return fact * np.exp(x) * np.log(np.pi) * np.cos(xi)

    x_pts2 = np.linspace(0.01, 3, 500)
    m_r = np.array([float(np.real(monster_integrand(x))) for x in x_pts2])
    m_i = np.array([float(np.imag(monster_integrand(x))) for x in x_pts2])
    cum_mr = cumulative_trapezoid(m_r, x_pts2, initial=0)
    cum_mi = cumulative_trapezoid(m_i, x_pts2, initial=0)
    monster_val = np.exp(np.clip(cum_mr[-1], -700, 700) +
                         1j*cum_mi[-1])
    s, v = safe_report("e^∫⌊e^x⌋!×ln(π^(e^x))×cos(xⁱ)dx", monster_val*n_earth, T_earth)
    results["⌊e^x⌋! inside integral"] = (s, v)

except Exception as e:
    print(f"  Monster integral failed: {e}")

# print()
print("── THE FINAL BOSS: ALL OF THE ABOVE MULTIPLIED ───────────────────────────────")

try:

    term1 = float(special.factorial(float(special.factorial(5,exact=True)),
                                     exact=False))          # (5!)! = 120!
    term2 = float(gamma(-0.5))                              # Γ(-1/2) = -2√π
    term3 = np.pi**2/6                                      # ζ(2)
    term4 = I_xx                                            # ∫e^(x^x)dx
    term5 = float(np.real(path_val)) * fact7               # 7!×original
    term6 = -1/12                                           # Ramanujan

    log_mag = (np.log(abs(term1)) + np.log(abs(term2)) +
               np.log(abs(term3)) + np.log(abs(term4)) +
               np.log(abs(term5)) + np.log(abs(term6)))
    sign    = (np.sign(term1)*np.sign(term2)*np.sign(term3)*
               np.sign(term4)*np.sign(term5)*np.sign(term6))
    n_boss  = sign * np.exp(np.clip(log_mag, -700, 700)) * n_earth

    s, v = safe_report("FINAL BOSS: ALL TERMS × n₀", n_boss, T_earth,
                       "log|n|={:.1f}".format(log_mag))
    results["FINAL BOSS"] = (s, v)

except Exception as e:
    print(f"  Final boss setup failed: {e}")

# SUMMARY
print()
print("="*90)
print("FINAL SCOREBOARD")
print("="*90)
survived = sum(1 for s,v in results.values() if "SURVIVED" in s)
broke    = sum(1 for s,v in results.values() if "BROKE" in s)
print(f"  Tests run:    {len(results)}")
print(f"  Survived:     {survived}")
print(f"  Broke:        {broke}")
print(f"  Score:        {survived}/{len(results)}")
print()
if broke == 0:
    print("Constant, mathematical rigour review passed")
else:
    print(f"  Finally broke {broke} time(s). Physics has limits.")

# PLOTS


# Plot 1: Ia magnitude across all pathological inputs (bar chart)
fig, ax = plt.subplots(figsize=(16, 8), facecolor=BG)
ax.set_facecolor(BG)

labels_plot = list(results.keys())
Ia_mags = []
colors_bar = []
color_cycle = [C1,C2,C3,C4,C5,C6,C7,C8,C1,C2,C3,C4,C5,C6,C7,C8,C1,C2,C3,C4]

for i, (name, (status, val_str)) in enumerate(results.items()):
    try:
        # Parse Re value
        if "Re=" in val_str:
            re_str = val_str.split("Re=")[1].split(" ")[0]
        else:
            re_str = val_str.split(" ")[0]
        re_val = float(re_str)
        Ia_mags.append(abs(re_val) if abs(re_val) > 0 else 1e-50)
    except:
        Ia_mags.append(1e-50)
    colors_bar.append(C5 if "BROKE" in status else color_cycle[i])

x = np.arange(len(labels_plot))
bars = ax.bar(x, Ia_mags, color=colors_bar, alpha=0.85,
              edgecolor="black", linewidth=1.2)
ax.set_yscale("log")
ax.set_xticks(x)
ax.set_xticklabels(labels_plot, rotation=45, ha="right",
                   fontsize=9, color=AXIS_COLOR)
ax.set_ylabel(r"$|Re(I_a)|$  (log scale)", fontsize=LABEL_SIZE,
              color=AXIS_COLOR, fontweight="bold")
ax.set_title("Pathological Input Stress Test — $I_a$ Magnitude Across All Cases\n"
             "Every bar = one test. Red = broke. Any other color = survived.",
             fontsize=TITLE_SIZE, color=AXIS_COLOR, fontweight="bold", pad=14)
style(ax)
fig.tight_layout(pad=1.5)
save(fig, "pathological_scoreboard")

# Plot 2: The monster integrand visualized
fig, axes = plt.subplots(1, 2, figsize=(14, 6), facecolor=BG)

# Left: factorial growth inside integral
x_fact = np.linspace(0.01, 3, 300)
fact_integrand = []
for x in x_fact:
    n_fl = min(int(np.floor(np.exp(x))), 12)
    fact_val = float(special.factorial(n_fl, exact=True))
    xi = np.exp(1j*np.log(max(x, 1e-10)))
    full = fact_val * np.exp(x) * np.log(np.pi) * np.cos(xi)
    fact_integrand.append(float(np.real(full)))

axes[0].semilogy(x_fact, np.abs(fact_integrand), color=C2, lw=LW,
                 label=r"$|\lfloor e^x \rfloor! \cdot e^x \ln(\pi) \cos(x^i)|$")
axes[0].set_xlabel(r"$x$", fontsize=LABEL_SIZE, color=AXIS_COLOR, fontweight="bold")
axes[0].set_ylabel(r"Integrand magnitude", fontsize=LABEL_SIZE,
                   color=AXIS_COLOR, fontweight="bold")
axes[0].set_title("Monster Integrand:\n" +
                  r"$\lfloor e^x \rfloor! \cdot e^x \ln(\pi^{e^x}) \cos(x^i)$",
                  fontsize=TITLE_SIZE, color=AXIS_COLOR, fontweight="bold")
leg(axes[0])
style(axes[0])

# Right: Ia survival across n magnitude (log scale)
n_sweep = np.logspace(-30, 60, 500) * n_earth
Ia_sweep = np.abs(np.real(Ia(n_sweep, T_earth)))
axes[1].loglog(n_sweep/n_earth, Ia_sweep, color=C1, lw=LW,
               label=r"$|I_a|$  across 90 orders of magnitude in $n$")
axes[1].axvline(1,   color=C4,   lw=1.5, ls="--", alpha=0.7,
                label="Normal air ($n = n_0$)")
axes[1].axvline(1e-55, color=C5, lw=1.5, ls=":", alpha=0.7)
axes[1].set_xlabel(r"$n/n_0$", fontsize=LABEL_SIZE,
                   color=AXIS_COLOR, fontweight="bold")
axes[1].set_ylabel(r"$|I_a|$", fontsize=LABEL_SIZE,
                   color=AXIS_COLOR, fontweight="bold")
axes[1].set_title(r"$I_a$ Across 90 Orders of Magnitude in $n$" +
                  "\nStill smooth. Still finite. Still won't break.",
                  fontsize=TITLE_SIZE, color=AXIS_COLOR, fontweight="bold")
leg(axes[1])
style(axes[1])

fig.suptitle("Nuclear Stress Test — Mathematical Architecture Survival",
             fontsize=TITLE_SIZE+1, color=AXIS_COLOR, fontweight="bold", y=1.02)
fig.tight_layout(pad=1.5)
save(fig, "NUKE2_monster_integrand_survival")

print()
print("'Constraints are not sufficient to break the equation.'")
print("                                                    — L_a Constant")
